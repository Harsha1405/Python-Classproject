
import random
import pandas as pd

def excluding_six():
    return random.randrange(0, 6)

def excluding_ten():
    return random.randrange(5, 10)


def three():
    return random.randrange(0, 11, 3)

def date(start_date, end_date):
    return random.choice(pd.date_range(start_date, end_date))


start_date = '2023-01-01'
end_date = '2023-12-31'

print("Random integer between 0 and 6 (excluding 6):", excluding_six())
print("Random integer between 5 and 10 (excluding 10):", excluding_ten())
print("Random integer between 0 and 10, with a step of 3:", three())
print("Random Date between 2023-01-01 and 2023-12-31:", date(start_date, end_date))
