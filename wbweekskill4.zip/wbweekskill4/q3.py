
import pandas as pd
import matplotlib.pyplot as plt


df = pd.read_csv("students.csv")


df_below_20 = df[df['Age'] < 20]
df_20_to_25 = df[(df['Age'] >= 20) & (df['Age'] <= 25)]
df_above_25 = df[df['Age'] > 25]


below_20 = df_below_20['Grade'].mean()
grade_20to25 = df_20_to_25['Grade'].mean()
above_25 = df_above_25['Grade'].mean()


ages = ['Below 20', '20-25', 'Above 25']
avg_grades = [below_20, grade_20to25, above_25]

plt.bar(ages, avg_grades, color='red')
plt.xlabel('Age Groups')
plt.ylabel('Average Grade')
plt.title('Average Grade for Different Age Groups')
plt.show()
