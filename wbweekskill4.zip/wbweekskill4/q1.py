import random
import string

def colorr_hex():

    color_hex = "#{:06x}".format(random.randint(0, 0xFFFFFF))
    return color_hex

def alphabet(length):

    letters = string.ascii_letters
    return ''.join(random.choice(letters) for _ in range(length))

def valuee(min_val, max_val):
    # Generate a random value between two integers (inclusive)
    return random.randint(min_val, max_val)

def multiple_of_7():

    return random.randint(0, 10) * 7


h = colorr_hex()
a = alphabet(8)
v = valuee(5, 15)
m = multiple_of_7()

print("Random Color Hex:",h)
print("Random Alphabetical String:", a)
print("Random Value between 5 and 15:", v)
print("Random Multiple of 7 between 0 and 70:",m)

