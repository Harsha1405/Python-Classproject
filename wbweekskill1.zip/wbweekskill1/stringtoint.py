n=input("Enter the number:")
print(type(n))
m=int(n)
print(type(m))
