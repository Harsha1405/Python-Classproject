n=int(input("enter the integer"))
print(float(n))
