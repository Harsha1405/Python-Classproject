a1=5+8j
a2=8+4j
print('addition of two complex',a1+a2)
a1=5.4
a2=8.6
print('addition of two float',a1+a2)
a1=7
a2=11
print('addition of two integers',a1+a2)
