n=int(input("enter the integer"))
st=input("enter the string")
print(int(st)+n)
