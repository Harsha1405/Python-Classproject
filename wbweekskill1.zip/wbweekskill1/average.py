numbers = []
n=int(input("Enter the size of array"))
for i in range(n):
    number = float(input("Enter a number: "))
    numbers.append(number)

average = sum(numbers) / len(numbers)

print("The average of the numbers is", average)
