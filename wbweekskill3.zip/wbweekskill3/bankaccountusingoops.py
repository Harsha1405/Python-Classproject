class BankAccount:
    def __init__(self,accountnumber,name,balance):
        self.accountnumber=accountnumber
        self.name=name
        self.balance=balance

    def deposit(self,amount):
        if amount>0:
            self.balance +=amount
            print("Deposit of $",{amount},"is Successful")
        else :
            print("Invalid deposit amount")

    def withdrawl(self,amount):
        if 0<amount<self.balance:
            self.balance-=amount
            print("withdrawl of  $",{amount},"is succesful")
        else :
              print("Withdrawl unsuccesful")

    def bankfees(self):
        fees=0.05*self.balance
        self.balance-=fees
        print("Bankfees is",{fees},"applied")

    def display(self):
        print(f"Account number :{self.accountnumber}")
        print(f"Account Holder :{self.name}")
        print(f"Account Balance :{self.balance}")


account1 = BankAccount(accountnumber=12345678,name="Harsha Vardhan ",balance=1000)
account1.display()
account1.deposit(500)
account1.withdrawl(200)
account1.bankfees()
account1.display()
