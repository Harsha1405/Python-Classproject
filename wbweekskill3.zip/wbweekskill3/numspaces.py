class myclass:
    class_variable = "I am a class Variable"

    def __init__(self, name):
        self.name = name

    def display_namespace(self):
        print("Namespace of the class:", dir(self))

obj = myclass("example")
obj.display_namespace()
