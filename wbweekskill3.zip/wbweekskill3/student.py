class student:
    def  __init__(self,student_id,student_name):
        self.student_id=student_id
        self.student_name=student_name
    def display(self):
        print("Attributes and their values:")
        for attributes_value in vars(self).items():
            print(f"{attributes_value}")
    def remove_student(self):
        del self.student_name
student1=student(12345,"John Doe" )
student1.remove_student()
student1.display()

