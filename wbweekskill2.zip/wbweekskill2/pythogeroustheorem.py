a1=int(input())
a2=int(input())
a3=int(input())
if ((a1*a1) == ((a2*a2) + (a3*a3))):
    print("yes")
else:
    print("No")
